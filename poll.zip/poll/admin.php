<?php
session_start();
require_once ("pdo.php");
if(!isset($_SESSION['success'])&&!isset($_SESSION['username']) &&!isset($_SESSION['admin'])){

    header("Location: index.php");
    return;
 
 }
if(isset($_POST['add'])){

    $name = $_POST['position_name'];
    $num = $_POST['max_can'];
    if(strlen($name)<1){
        $msg = "*position name is required";
        $_SESSION['error'] = $msg;
        header("Location: admin.php");
        return;
    }

    

    $sql = "SELECT * FROM polling.position WHERE name = :name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ':name' => $_POST['position_name']
       ));
    $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
    // new work
    // echo "Taken.....";
    if ( $row1 == true ) {
        $msg = "*position name already exist";
        $_SESSION['error'] = $msg;
        header("Location: admin.php");
        return;
    }

    

    $stmt = $pdo->prepare('INSERT INTO polling.position
    (name, maximum_candidate)
    VALUES ( :name, :max)');
    $stmt->execute(array(
        ':name' => $_POST['position_name'],
        ':max' => $_POST['max_can'])
    );
    $position_id = $pdo->lastInsertId();


    $stmt = $pdo->prepare('INSERT INTO polling.candidate_number
    (position_id, max)
    VALUES ( :id, :max)');
    $stmt->execute(array(
        ':id' => $position_id,
        ':max' => $_POST['max_can'])
    );
    
    $_SESSION['success'] = "Position added";
    header("Location: admin.php");
    return;
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin panel</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/319c52724b.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="script.js"> 
        </script>
        <script>
            function validateForm()
    {
    var x=document.forms["myForm"]["max_can"].value;
    var lngth =x.length;
    var numbers = /^[0-9]+$/;
    if (lngth<1)
      {
      alert("Please insert the value of maximum candidate");
      return false;
      }
      if(!x.match(numbers)){
        alert("Maximum candidate should be numeric");
        return false;
      }
      return true;
    }
        </script>

</head>
<body>
    <header>
        <nav>
            <span class="qz">
                <i class="fa fa-bars"></i>
            </span>
            <a class = "logo" href="#">Administrator Panel <span class="bar">|</span> Polling System</a>
            <ul>
                <li> <a class = "current" href="admin.html">Home</a></li>
                <li> <a href="manage.php">Manage Candidates</a></li>
                <li> <a href="results.php">Results</a></li>
                <li> <a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div id = "msg">
        <?php
            if ( isset($_SESSION['error']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: red; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['error'])."</p>\n");
                unset($_SESSION['error']);
            }
            if ( isset($_SESSION['success']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: green; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['success'])."</p>\n");
                unset($_SESSION['success']);
            }
            
            ?>  
        </div>
        
        <div class = "position">
            <h1>Add New Position For Poll</h1>
            <button id="add_position" class="btn btn-outline-primary"><span class="rgt">Add</span>
                <span class="rgt1"><strong>+</strong> </span></button> 
            
                <div id="add">
                    <br>

                <form name = "myForm" onsubmit=" return validateForm()" method="post">
                    
                    <div class="form-group mt-6" >
                    <label for="position_name">Position Name:</label>
                        <input type="text" class="form-control form-control-md" id="position_name" name="position_name" >
                      </div>
                      <div class="form-group mt-6" >
                    <label for="max_can">Max Candidates:</label>
                        <input type="text" class="form-control form-control-md" id="max_can" name="max_can" >
                      </div>

                    <input type="submit" class="btn btn-primary" value="Add" name = "add">
                </form>
                <script>
                    $(document).ready(function(){
                        $('#add_position').click(function(event){
                            $("#add").toggle();
                            var x = document.getElementById("add");
                            if (x.style.display !== "none"){
                                $(".rgt", this).text("Remove");
                                $(".rgt1", this).text("-");
                            }
                            else{
                                $(".rgt", this).text("Add");
                                $(".rgt1", this).text("+");
                            }
                        });
                    });                 
                </script>
            </div>
        </div>
        <br>
        <hr>

        <div class = "position">
            <h1>Available Position For Poll</h1>
            <button id="show_position" class="btn btn-outline-primary"><span class="rgt">Show</span>
                </button> 
                    <br>
                <div id="show" style = "display: none;margin-top:2%;margin-left: 3%;margin-right: 3%;"></div>
                <br>
                
                <script>
                    $(document).ready(function(){
                        $('#show_position').click(function(event){
                            $("#show").toggle();
                            document.getElementById("msg").style.display = "none";
                            var x = document.getElementById("show");
                            if (x.style.display !== "none"){
                                $(".rgt", this).text("Close");
                                
                            }
                            else{
                                $(".rgt", this).text("show");
                            }
                            var req = new XMLHttpRequest();
                        req.open('GET','returnhandler.php',true );
                
                        req.onload = function(){
                            if(req.status==200){
                            var namez = JSON.parse(req.responseText);
                            var display = '<table class="table table-hover">';
                            display += '<thead class="thead-dark"><tr><th scope="col">Position Id</th><th scope="col">Position Name</th><th scope="col">Candidate Capacity</th><th scope="col">Delete</th></tr></thead><tbody>';
                
                            for (var i in namez){
                                display += '<tr id = "delete'+namez[i].position_id+'"><td>'+namez[i].position_id+
                                "</td><td>"+namez[i].name+
                                "</td><td>"+namez[i].maximum_candidate+
                                '</td><td><button onclick = "deleteajax('+namez[i].position_id+')" type="button" class="btn btn-danger btn-sm">Delete</button>'+
                                "</td></tr>";
                            }
                            display += '</tbody></table>' ;
                            document.getElementById('show').innerHTML=display;
                        }
                    }
                        req.send();
                        });
                    });  

                   function deleteajax(id){
                       if(confirm('are tou sure?')){
                           $.ajax({
                               type: 'post',
                               url:'handler.php',
                               data:{delete_id:id},
                               success:function(data){
                                    $('#delete'+id).hide('slow');
                               }
                           });
                       }
                   }

                </script>
            
        </div>
    </main> 
    
</body>
</html>