<?php 

$conn = mysqli_connect('localhost','jn','0000','polling') ;
// or die(mysqli_error($conn));
//session_start();


?>
<?php
$pdo = new PDO('mysql:host=localhost;port=3306;dbname=polling', 'jn', '0000');
// See the "errors" folder for details...
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
