<?php
$connection = mysqli_connect('localhost', 'jn', '0000', 'polling');

    $id = $_POST['delete_id'];
    $sql = "DELETE FROM candidate WHERE candidate_id='$id'";
    mysqli_query($connection, $sql);

    $stmt = $pdo->prepare("SELECT position_id FROM polling.candidate WHERE candidate_id =:xyz");

    $stmt->execute(array(":xyz" => $id));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
   
    $pid = $row["position_id"];

    $stmt1 = $pdo->prepare("SELECT count, max FROM polling.candidate_number WHERE position_id =:xy");

    $stmt1->execute(array(":xy" => $pid));
    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
   
    $count = $row["count"];
    echo $count;
    $count -= 1;

    $sql1 = "UPDATE polling.candidate_number SET count = :count
            WHERE position_id = :id";
        $stmt = $pdo->prepare($sql1);
        $stmt->execute(array(
            ':count' => $count,
            ':id' => $pid)
        );
        
    

?>