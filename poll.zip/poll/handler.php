<?php
$connection = mysqli_connect('localhost', 'jn', '0000', 'polling');
    $id = $_POST['delete_id'];
    $sql = "DELETE FROM position WHERE position_id='$id'";
    mysqli_query($connection, $sql);

?>