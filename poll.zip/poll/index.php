<?php 

require_once 'db.php';
session_start();

$errors = array(); 

// REGISTER USER
if (isset($_POST['register'])) {
  // receive all input values from the form
  $name = $_POST['name'];
  $dob = $_POST['dob'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $division = $_POST['division'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $cpassword = $_POST['cpassword'];

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($name)) { array_push($errors, "Name is required"); }
  if (empty($dob)) { array_push($errors, "Date of Birth is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($phone)) { array_push($errors, "Phone no is required"); }
  if (empty($division)) { array_push($errors, "Division is required"); }
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $cpassword) {
	array_push($errors, "The two passwords do not match");
  }
else{
    $type='user';
$sql ="INSERT INTO users (name,dob,email,phone,division,username,password,type) 
      VALUES(:name, :dob, :email, :phone, :division, :username, :password,:type)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array(
  ':name' => $name,
  ':dob' => $dob,
  ':email' =>$email,
  ':phone' => $phone,
  ':division' => $division,
  ':username' =>$username,
  ':password' =>$password,
  ':type' =>$type));

  // echo "Check3...................................................................";

// echo "Sucessfully registered";
 $_SESSION['username']=$_POST['name'];
 $_SESSION['success']="Successfilluy registered";
  header( 'Location: userPage.php' ) ;
  return;
    }
}

// LOGIN USER and admin
if (isset($_POST['login'])) {
        // $username = mysqli_real_escape_string($conn, $_POST['username']);
        // $password = mysqli_real_escape_string($conn, $_POST['password']);
    
        // if (empty($username)) {
        //     array_push($errors, "Username is required");
        // }
        // if (empty($password)) {
        //     array_push($errors, "Password is required");
        // }
    ////................................................working on this..................................
    $type1 = $_POST['type'];
    //   $type2 = $_POST['type'];
    $t1='admin';
    //   $t2='user';
    $username = $_POST['username'];
    $password = $_POST['password'];
    // jhsbduhbgd

    $sql = "SELECT * FROM users WHERE username = :username AND password = :password";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ':username' => $username,
        ':password' =>  $password));
    $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
    // new work
    // echo "Taken.....";
    if ( $row1 == false ) {
        echo "Wrong email/password";
    }
    else{
        if($type1 == $t1) {
            // $selected = $_POST['type'];
            // echo 'You have chosen: ' . $selected;
        
                // $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
                $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username and password=:password");
                $stmt->execute(array(
                    ':username' =>$username,
                    ':password' =>$password));
                $row2 = $stmt->fetch(PDO::FETCH_ASSOC);
                if($row2 == true){
                    $_SESSION['success'] = 'Admin portal';
                    // $_SESSION['email'] = $_POST['email'];
                    $_SESSION['username'] = $row2['username'] ;
                    $_SESSION['admin'] = 'ok' ;
        
        
                    header( 'Location: admin.php' ) ;
                    return;
                }
                // }else{
                //     $_SESSION['success4'] = 'Employee portal';
                //     $_SESSION['id'] = $_POST['id'];
                //     $_SESSION['email'] = $_POST['email'];
                //     header( 'Location: employee.php' ) ;
                //     return;
                // }
                // $results = mysqli_query($db, $query);
                // if (mysqli_num_rows($results)) {
                //   $_SESSION['username'] = $username;
                //   $_SESSION['success'] = "You are now logged in";
                //   header('location: adminPage.php');
        
            }
            else{
                // SELECT * FROM users WHERE username = 'hr' AND password = 'hr'
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username and password=:password");
                $stmt->execute(array(
                    ':username' =>$username,
                    ':password' =>$password));
                $row2 = $stmt->fetch(PDO::FETCH_ASSOC);
                if($row2 == true){


                    $sql = "SELECT * FROM user WHERE Name = :username AND Password = :password";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute(array(
                        ':username' => $row2['name'],
                        ':password' =>  $row2['password']));
                    $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ( $row1 == false ) {
                        $stmt = $pdo->prepare('INSERT INTO polling.user
                    (Name, Email, Password)
                    VALUES ( :uid, :fn, :ln)');
                    $stmt->execute(array(
                        ':uid' => $row2['name'],
                        ':fn' => $row2['email'],
                        ':ln' => $row2['password']
                        )
                    );
                    $user_id = $pdo->lastInsertId();

                    }
                    $_SESSION['user'] = 'ok' ;
                    $_SESSION['success'] = 'User portal';
                    // $_SESSION['email'] = $_POST['email'];
                    $_SESSION['username'] = $row2['username'] ;
                    $_SESSION['user_email'] = $row2['email'];
                    $_SESSION['user_id'] = $user_id;
                    header( 'Location: vote3.php' ) ;
                    return;
                }
            }

    }

}





//   kjsnuhbxygzsvx




?>

<html lang="en">
<head>
	<title>Online Polling System</title>
    <!-- <link rel="stylesheet" href="style.css"> -->

    <style>
    
    @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.min.css');

* {
    margin: 0px;
    padding: 0px;
  }

 .formBox{
     height: 100%;
     width: 100%;
     background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)), url(img/shutterstock_200804441.jpg); 
     background-position: center;
     background-size: cover;
     position: absolute;
 }

 .form-box{
     float: right;
     width: 380px;
     height: 550px;
     border-radius: 30px;
     position: relative;
     margin: 4% auto;
     background: rgba(255, 255, 255, 0.7);
     padding: 4px;
     overflow: hidden;
 }

 .button-box{
     width: 220px;
     margin: 35px auto;
     position: relative;
     box-shadow: 0 0 20px 9px #ff2b242a; 
     border-radius: 30px;
     color: transparent;
 }

 .toggle-btn{
     padding: 10px 30px;
     cursor: pointer;
     background: transparent;
     border: 0;
     outline: none;
     position: relative;
     color: white;
 }

 #btn{
     top: 0;
     left: 0;
     position: absolute;
     width: 110px;
     height: 100%;
     background: linear-gradient(to right, #740202, #000000);
     border-radius: 30px;
     transition: 0.5s;
 }

.loginForm{
    top: 180px;
    position: absolute;
    width: 280px;
    transition: 0.5s;
}

.registerForm{
    top: 100px;
    position: absolute;
    width: 280px;
    transition: 0.5s;
}

.form-control{
    width: 100%;
    padding: 10px 0;
    margin: 5px 0;
    border-left: 0;
    border-right: 0;
    border-top: 0;
    border-bottom: 1px solid #999;
    
    background: transparent;
}

.form-class i {
	visibility: hidden;
	position: absolute;
	top: 40px;
	right: 10px;
}

.form-class.error input {
	border-color: #e74c3c;
}

.form-class i {
	visibility: hidden;
	position: absolute;
	top: 40px;
	right: 10px;
}

.form-class.success i.fa-check-circle {
	color: #2ecc71;
	visibility: visible;
}

.form-class.error i.fa-exclamation-circle {
	color: #e74c3c;
	visibility: visible;
}

.form-class small {
	color: #e74c3c;
	position: absolute;
	bottom: 0;
	left: 0;
	visibility: hidden;
}

.form-control.error small {
	visibility: visible;
}

.submit-btn{
    width: 85%;
    padding: 10px 30px;
    cursor: pointer;
    display: block;
    margin: auto;
    background: linear-gradient(to right, #740202, #000000);
    border: 0;
    outline: none;
    border-radius: 30px;
    color: white;
}

#login{
    left: 50px;
}

#register{
    left: 450px;
}

    </style>


</head>
<body>
    <div class="formBox">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">Login</button>
                <button type="button" class="toggle-btn" onclick="register()">Register</button>
            </div>
<!-- hksdbuhabusgvxagvsygsxayfvztfcxtafcst -->
            <form id="login" class="loginForm" action="" method="post">
                    <div class="form-group">
                            <select  name="type">
                                <!-- <option selected="">-Select User Type-</option> -->
                                <option   value="admin">admin</option>
                                <option  value="user">user</option>
                            </select>
                    </div>

                    <div class="form-class">
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                        <i class="fas fa-check-circle"></i>
                        <i class="fas fa-exclamation-circle"></i>
                        <small>Error Message</small>
                    </div>

                    <div class="form-class">
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                        <i class="fas fa-check-circle"></i>
                        <i class="fas fa-exclamation-circle"></i>
                        <small>Error Message</small>
                    </div>
                    <br>
                    <div class="form-class">
                        <button type="submit" name="login" class="submit-btn">Login</button>
                        
                    </div>
            </form>
<!-- register -->
   <form id="register" class="registerForm" action="regQuery.php" method="post">
            <div class="form-class">
					<input type="text" name="name" class="form-control" placeholder="Name" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
				</div>
                
				<!--div class="form-class">
					<input type="text" id="lname" class="form-control" placeholder="Last Name" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
				</div-->
                
				<div class="form-class">
					<input type="date" name="dob" class="form-control" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
				</div>

				<div class="form-class">
					<input type="email" name="email" class="form-control" placeholder="Email" require>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
                </div>
                
                <div class="form-class">
					<input type="text" name="phone" class="form-control" placeholder="Phone No" require>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
				</div>

		        <div class="form-class">
                     <select name="division" class="custom-select">
                        <!-- <option selected="">-Select Division-</option> -->
                        <option value="dhaka">Dhaka</option>
                        <option value="rajshahi">Rajshahi</option>
                        <option value="chittagong">Chittagong</option>
                        <option value="sylhet">Sylhet</option>
                        <option value="barisal">Barisal</option>
                        <option value="rangpur">Rangpur</option>
                        <option value="mymensingh">Mymensingh</option>
                        <option value="khulna">Khulna</option>
                    </select>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
                </div>

				<div class="form-class">
					<input type="text" name="username" class="form-control" placeholder="Username" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
				</div>

				<div class="form-class">
					<input type="password" name="password" class="form-control" placeholder="New Password" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
                </div>
                <div class="form-class">
					<input type="password" name="cpassword" class="form-control" placeholder="Confirm Password" required>
                    <i class="fas fa-check-circle"></i>
			        <i class="fas fa-exclamation-circle"></i>
                    <small>Error Message</small>
                </div>

				<div class="form-class">
                    <button type="submit" name="register" class="submit-btn">Register</button>
                </div>
     </form>
   </div>
</div>

    <script>
        var x = document.getElementById("login");
        var y = document.getElementById("register");
        var z = document.getElementById("btn");

        function register(){
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }
        function login(){
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0px";
        }
    </script>
</body>
</html>