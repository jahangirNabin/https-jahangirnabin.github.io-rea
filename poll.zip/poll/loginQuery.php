<?php
session_start();
if(isset($_SESSION['success'])&&isset($_SESSION['username'])){

   echo "Welcome ".$_SESSION['success']." to the system";
   echo "<br>Your username is ".$_SESSION['username'];

}
 ?>
<h1>Successful signup</h1>