
<?php
session_start();
require_once ("pdo.php");
if(!isset($_SESSION['success'])&&!isset($_SESSION['username']) &&!isset($_SESSION['admin'])){

    header("Location: index.php");
    return;
 
 }
if(isset($_POST['add'])){

    if(empty($_POST['candidate'])) {
        echo 'You have chosen: ' . $selected;
        $msg = "*Please select the position";
        $_SESSION['error'] = $msg;
        header("Location: manage.php");
        return;
    }

    $sql = "SELECT * FROM polling.candidate WHERE candidate_name = :name AND position_name = :position_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ':name' => $_POST['candidate_name'],
        ':position_name' => $_POST['candidate']
       ));
    $row1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ( $row1 == true ) {
        $msg = "*candidate name in ".$_POST['candidate']." position already exist";
        $_SESSION['error'] = $msg;
        header("Location: admin.php");
        return;
    }

    $stmt = $pdo->prepare("SELECT position_id FROM polling.position WHERE name =:xyz");

    $stmt->execute(array(":xyz" => $_POST['candidate']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
   
    $id = $row["position_id"];

    $stmt1 = $pdo->prepare("SELECT count, max FROM polling.candidate_number WHERE position_id =:xy");

    $stmt1->execute(array(":xy" => $id));
    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
   
    $count = $row["count"];
    $max = $row["max"];
    
    if($count >=  $max){
        $msg = "*max candidate number is ".$max.", which has exceed";
        $_SESSION['error'] = $msg;
        header("Location: manage.php");
        return;
    }

    $count += 1;

    $sql = "UPDATE polling.candidate_number SET count = :count
            WHERE position_id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array(
            ':count' => $count,
            ':id' => $id)
        );


    $stmt = $pdo->prepare('INSERT INTO polling.candidate
    (candidate_name, position_id, position_name)
    VALUES ( :name, :position_id, :position_name)');
    $stmt->execute(array(
        ':name' => $_POST['candidate_name'],
        ':position_id' => $id,
        ':position_name' => $_POST['candidate'])
    );
    
    $_SESSION['success'] = "Position added";
    header("Location: manage.php");
    return;
    
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin panel</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/319c52724b.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="script.js"> 
        </script>
        <script>
            function validateForm()
    {
    var x=document.forms["myForm"]["candidate_name"].value
    var lngth =x.length;
    if (lngth<1)
      {
      alert("Please insert the value of candidate name");
      return false;
      }
      return true;
    }
        </script>

</head>
<body>
    <header>
        <nav>
            <span class="qz">
                <i class="fa fa-bars"></i>
            </span>
            <a class = "logo" href="#">Administrator Panel <span class="bar">|</span> Polling System</a>
            <ul>
                <li> <a href="admin.php">Home</a></li>
                <li> <a class = "current" href="manage.html">Manage Candidates</a></li>
                <li> <a href="results.php">Results</a></li>
                <li> <a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>

    <div id = "msg">
        <?php
            if ( isset($_SESSION['error']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: red; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['error'])."</p>\n");
                unset($_SESSION['error']);
            }
            if ( isset($_SESSION['success']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: green; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['success'])."</p>\n");
                unset($_SESSION['success']);
            }
            
            ?>  
        </div>

        <div class = "position">
            <h1>Add New Candidate For Position</h1>
            <button id="add_position" class="btn btn-outline-primary"><span class="rgt">Add</span>
                <span class="rgt1"><strong>+</strong> </span></button> 
            
                <div id="add">
                    <br>
                <form method="post" onsubmit="return validateForm()" name = "myForm">
                    <label for="candidate_name">Candidate Name:</label>
                    <div class="form-group mt-3">
                        <input type="text" class="form-control form-control-lg" id="candidate_name" name="candidate_name">
                      </div>
                      <br>
                      <label for="sel1">Candidate Position:</label>
                      <div class="form-group">
                        <select name = "candidate" class="form-control" id="sel1">
                          <option value="" disabled selected>select</option>
                          <?php
                          $stmt = $pdo->query("SELECT name FROM polling.position");

                          while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
                            echo '<option value = "'.$row['name'].'">'.$row['name'].'</option>';
                            
                        }
                          
                          ?>
                        </select>
                      </div>
                    <input type="submit" class="btn btn-primary" value="Add" name ="add">
                </form>
                <script>
                    $(document).ready(function(){
                        $('#add_position').click(function(event){
                            $("#add").toggle();
                            var x = document.getElementById("add");
                            if (x.style.display !== "none"){
                                $(".rgt", this).text("Remove");
                                $(".rgt1", this).text("-");
                            }
                            else{
                                $(".rgt", this).text("Add");
                                $(".rgt1", this).text("+");
                            }
                        });
                    });
                </script>
            </div>
        </div>
        <br>
        <hr>
        <div class = "position">
            <h1>Available Candidates</h1>
            <button id="show_position" class="btn btn-outline-primary"><span class="rgt">Show</span>
                </button> 
                    <br>
                <div id="show" style = "display: none;margin-top:2%;margin-left: 3%;margin-right: 3%;"></div>
                <br>
                
                <script>
                    $(document).ready(function(){
                        $('#show_position').click(function(event){
                            $("#show").toggle();
                            document.getElementById("msg").style.display = "none";
                            var x = document.getElementById("show");
                            if (x.style.display !== "none"){
                                $(".rgt", this).text("Close");
                                
                            }
                            else{
                                $(".rgt", this).text("show");
                            }
                            var req = new XMLHttpRequest();
                        req.open('GET','returnhandler1.php',true );
                
                        req.onload = function(){
                            if(req.status==200){
                            var namez = JSON.parse(req.responseText);
                            var display = '<table class="table table-hover">';
                            display += '<thead class="thead-dark"><tr><th scope="col">Candidate Id</th><th scope="col">Candidate Name</th><th scope="col">Candidate Position</th><th scope="col">Delete</th></tr></thead><tbody>';
                
                            for (var i in namez){
                                display += '<tr id = "delete'+namez[i].candidate_id+'"><td>'+namez[i].candidate_id+
                                "</td><td>"+namez[i].candidate_name+
                                "</td><td>"+namez[i].position_name+
                                '</td><td><button onclick = "deleteajax('+namez[i].candidate_id+')" type="button" class="btn btn-danger btn-sm">Delete</button>'+
                                "</td></tr>";
                            }
                            display += '</tbody></table>' ;
                            document.getElementById('show').innerHTML=display;
                        }
                    }
                        req.send();
                        });
                    });  

                   function deleteajax(id){
                       if(confirm('are tou sure?')){
                           $.ajax({
                               type: 'post',
                               url:'delete.php',
                               data:{delete_id:id},
                               success:function(data){
                                    $('#delete'+id).hide('slow');
                               }
                           });
                           $.ajax({
                               type: 'post',
                               url:'update.php',
                               data:{delete_id:id},
                               success:function(data){
                                    // $('#delete'+id).hide('slow');
                               }
                           });
                       }
                   }

                </script>
            
        </div>
        
    </main> 
</body>
</html>