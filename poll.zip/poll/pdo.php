<?php
try{
    $pdo = new PDO('mysql:host = localhost;port = 3306;dbname = polling', 'jn', '0000');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}catch(PDOexception $e){
    echo $e->getMessage();
    die();
}
    ?>