
<?php
session_start();
require_once ("pdo.php");
if(!isset($_SESSION['success'])&&!isset($_SESSION['username']) &&!isset($_SESSION['admin'])){

    header("Location: index.php");
    return;
 
 }
if(isset($_POST['add'])){
    
    if(empty($_POST['candidate'])) {
        echo 'You have chosen: ' . $selected;
        $msg = "*Please select the position";
        $_SESSION['error'] = $msg;
        header("Location: results.php");
        return;
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin panel</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/319c52724b.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>
<body>
    <header>
    <nav>
            <span class="qz">
                <i class="fa fa-bars"></i>
            </span>
            <a class = "logo" href="#">Administrator Panel <span class="bar">|</span> Polling System</a>
            <ul>
                <li> <a  href="admin.php">Home</a></li>
                <li> <a href="manage.php">Manage Candidates</a></li>
                <li> <a class = "current" href="results.php">Results</a></li>
                <li> <a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>

    <div id = "msg">
        <?php
            if ( isset($_SESSION['error']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: red; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['error'])."</p>\n");
                unset($_SESSION['error']);
            }
            if ( isset($_SESSION['success']) ) {
                // Look closely at the use of single and double quotes
                echo('<p style="color: green; width: 80%; margin: 2% auto">'.htmlentities($_SESSION['success'])."</p>\n");
                unset($_SESSION['success']);
            }
            
            ?>  
        </div>

        <div class = "position">
            <!-- <h1>Show Poll Result</h1>
            <button id="add_position" class="btn btn-outline-primary"><span class="rgt">Show</span>
                </button>  -->
            
                <div id="adda">
                    <br>
                <form method="post" style="margin-left:3%">
                      <label for="sel1">Select Poll Position For Result:</label>
                      <div class="form-group">
                        <select name = "candidate" class="form-control" id="sel1">
                          <option value="" disabled selected>select</option>
                          <?php
                          $stmt = $pdo->query("SELECT name FROM polling.position");

                          while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
                            echo '<option value = "'.$row['name'].'">'.$row['name'].'</option>';
                            
                        }
                          
                          ?>
                        </select>
                      </div>
                    <input style = "margin-left:3%;" type="submit" id = "sub" class="btn btn-primary" value="show" name ="add">
                </form>
                <?php
                if (isset($_POST['add'])){
                    $sel_position = $_POST['candidate'];
                    $stmt1 = $pdo->prepare("SELECT a.vote, b.position_id FROM polling.position as b JOIN polling.vote_per_position as a ON b.position_id = a.position_id WHERE b.name =:xy");

                    $stmt1->execute(array(":xy" => $sel_position));
                    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
                    if($row){
                        $vote = $row["vote"];
                    $id = $row["position_id"];
                    echo '<p style="color:red">You have select the '.$sel_position.' position</p>';

                    $stmt = $pdo->prepare("SELECT a.noOfVote, b.candidate_name FROM polling.vote_per_candidate as a JOIN polling.candidate as b ON a.candidate_id = b.candidate_id WHERE a.position_id =:y");
                    $stmt->execute(array(":y" => $id));
                          while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
                              $n = $row['candidate_name'];
                            $d = ($row['noOfVote'] / $vote) * 100 ; 
                            echo '<div class="progress" id = "rs" style="margin-left:3%;width:70%;margin-top:2%">';
                            echo '<div class="progress-bar" role="progressbar" style="width: '.$d.'%;" aria-valuenow="'.$d.'" aria-valuemin="0" aria-valuemax="100">'.$n.' - '.$d.'%</div>';
                            echo '</div>';

                        }
                    }else{
                        echo '<p style="color:red">*No vote yet on selected position</p>';
                    }
                    
                    
                }
                
                ?>
            </div>
        </div>
        <br>
        <hr>
        
    </main> 
</body>
</html>