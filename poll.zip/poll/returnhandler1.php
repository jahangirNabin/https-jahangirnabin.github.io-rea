<?php
$connection = mysqli_connect("localhost", "jn","0000", "polling");
$sql = "SELECT * FROM candidate";
$result = mysqli_query($connection, $sql);

//Get the data
$identifiers = mysqli_fetch_all($result, MYSQLI_ASSOC);
echo json_encode($identifiers);
?>