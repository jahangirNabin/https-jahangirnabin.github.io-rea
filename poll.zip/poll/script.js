function validateForm()
    {
    var x = document.getElementById('max_can').value;
    var lngth =x.length;
    var numbers = /^[0-9]+$/;
    if (lngth<1)
      {
      alert("Please insert the value of maximum candidate");
      return false;
      }
      if(!x.match(numbers)){
        alert("Maximum candidate should be numeric");
        return false;
      }
      return true;
    }

    function validateForm()
    {
    
    var x = document.getElementById("candidate_name").value;
    var lngth =x.length;
    if (lngth<1)
      {
      alert("Please insert the value of candidate name");
      return false;
      }
      return true;
    }