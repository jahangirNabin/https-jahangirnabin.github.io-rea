-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2020 at 08:54 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `polling`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `username`, `password`) VALUES
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `candidate_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `candidate_name` varchar(100) NOT NULL,
  `position_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`candidate_id`, `position_id`, `candidate_name`, `position_name`) VALUES
(19, 15, 'Ruhul Amin', 'chairman'),
(20, 15, 'Rakib', 'chairman'),
(21, 17, 'Sakib', 'Minister'),
(22, 17, 'Nabin', 'Minister'),
(23, 15, 'sakil', 'chairman');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_number`
--

CREATE TABLE `candidate_number` (
  `id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate_number`
--

INSERT INTO `candidate_number` (`id`, `position_id`, `count`, `max`) VALUES
(7, 15, 3, 4),
(9, 17, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `maximum_candidate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`position_id`, `name`, `maximum_candidate`) VALUES
(15, 'chairman', 4),
(17, 'Minister', 4);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Email`, `Password`) VALUES
(7, 'hr', 'hr@gmail.com', 'hr'),
(8, 't', 't@gmail.com', 't'),
(9, 'Jahangir Nabin', 'hr@gmail.com', 'vc');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dob` datetime NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `dob`, `email`, `phone`, `division`, `username`, `password`, `type`) VALUES
(8, 'admin', '2020-09-11 19:07:26', 'admin@gmail.com', '94747646664664', 'Dhaka', 'admin', 'admin', 'admin'),
(9, 'hr', '2020-09-10 00:00:00', 'hr@gmail.com', '+9199888', 'dhaka', 'hr', 'hr', 'user'),
(10, 't', '2020-09-23 00:00:00', 't@gmail.com', '98687574', 'dhaka', 't', 't', 'user'),
(11, 'university', '2020-09-25 00:00:00', 'u@gmail.com', '+9199888', 'chittagong', 'admin', 'admin', 'user'),
(12, 'Jahangir Nabin', '2020-09-01 00:00:00', 'jahangirnabin2@gmail.com', '01798724156', 'dhaka', 'nabin', '1234', 'user'),
(13, 'Jahangir Nabin', '2020-09-11 00:00:00', 'hr@gmail.com', '01798724156', 'dhaka', 'vc', 'vc', 'user'),
(14, 'Ruhul', '2018-07-26 00:00:00', 't@gmail.com', '01798724156', 'dhaka', 'dc', 'e', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `voted_position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`id`, `user_id`, `voted_position`) VALUES
(19, 0, 'vfd'),
(20, 0, 'fbdfbd'),
(21, 8, 'fbdfbd'),
(22, 8, 'vfd'),
(23, 9, 'fbdfbd'),
(24, 9, 'vfd'),
(25, 0, 'chairman'),
(26, 0, 'Minister');

-- --------------------------------------------------------

--
-- Table structure for table `vote_per_candidate`
--

CREATE TABLE `vote_per_candidate` (
  `id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `noOfVote` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote_per_candidate`
--

INSERT INTO `vote_per_candidate` (`id`, `position_id`, `candidate_id`, `noOfVote`) VALUES
(22, 15, 20, 1),
(23, 17, 22, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vote_per_position`
--

CREATE TABLE `vote_per_position` (
  `id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `vote` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote_per_position`
--

INSERT INTO `vote_per_position` (`id`, `position_id`, `vote`) VALUES
(6, 15, 1),
(7, 17, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`candidate_id`),
  ADD KEY `candidate_ibfk_1` (`position_id`);

--
-- Indexes for table `candidate_number`
--
ALTER TABLE `candidate_number`
  ADD PRIMARY KEY (`id`),
  ADD KEY `position_id` (`position_id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `vote_per_candidate`
--
ALTER TABLE `vote_per_candidate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `position_id` (`position_id`),
  ADD KEY `vote_per_candidate_ibfk_2` (`candidate_id`);

--
-- Indexes for table `vote_per_position`
--
ALTER TABLE `vote_per_position`
  ADD PRIMARY KEY (`id`),
  ADD KEY `position_id` (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `candidate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `candidate_number`
--
ALTER TABLE `candidate_number`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `vote_per_candidate`
--
ALTER TABLE `vote_per_candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `vote_per_position`
--
ALTER TABLE `vote_per_position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidate`
--
ALTER TABLE `candidate`
  ADD CONSTRAINT `candidate_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `candidate_number`
--
ALTER TABLE `candidate_number`
  ADD CONSTRAINT `candidate_number_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vote_per_candidate`
--
ALTER TABLE `vote_per_candidate`
  ADD CONSTRAINT `vote_per_candidate_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vote_per_candidate_ibfk_2` FOREIGN KEY (`candidate_id`) REFERENCES `candidate` (`candidate_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vote_per_position`
--
ALTER TABLE `vote_per_position`
  ADD CONSTRAINT `vote_per_position_ibfk_1` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
