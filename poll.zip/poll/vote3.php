<?php

$con = mysqli_connect("localhost", "jn", "0000", "polling");
session_start();
if(!isset($_SESSION['user'])){

    header("Location: index.php");
    return;
 
 }
if(!isset($_SESSION["success"]) && !isset($_SESSION['user_email'])){ 
    header("Location: index.php");
    return;
  }


$query = "SELECT * FROM `position`";

$result1 = mysqli_query($con, $query);

?>

<!DOCTYPE html>

<html>

    <head>
    <link rel="stylesheet" href="style.css">

    <title> PHP SELECT OPTIONS FROM DATABASE </title>
        
    </head>

    <body>
    <header>
    <nav>
    <a class = "logo" href="#">Online Polling System</a>
    <ul class = "nav_link">
    <li><a class = "current" href="vote3.php">Home</a></li>
    <li><a href="resultsu.php">Results</a></li>
    <li><a href="logout.php">Log out</a></li>
    </ul>
    </nav>
    </header>

    <form action="vote3.php" method = "post">
        <!--Method One-->
    <div class="position">
    <h2>Please Select a Position Then Vote</h2>
        <select  name="position" >

            <?php while($row1 =
             mysqli_fetch_array($result1)):;?>

            <option><?php echo $row1[1];?></option>

            <?php endwhile;?>

        </select>
    
        <input type="submit" name="submit" value="find candidate">
        
    </form>

    
    <?php
    
    if(isset($_POST['submit']))
    {
        $_SESSION['position'] = $_POST['position'];
        $selected = $_SESSION['position'];
        $email = $_SESSION['user_email'];
                echo '<p style = "color:green">You have chosen  to vote in ' . $selected.'</p>';
                $sql="SELECT * FROM `candidate` WHERE `position_name`='$selected'";
                $res=mysqli_query($con, $sql);
                if (mysqli_num_rows($res) > 0) {
                    // output data of each row
                    echo '<form action="vote3.php" method="post">';
                    while($row = mysqli_fetch_assoc($res)) {
                    echo "<br>";
                        
                        echo '<input type="radio" id="vote" value='.$row["candidate_name"].' name="options">';
                        echo "<i>";
                        echo " Name: " . $row["candidate_name"] ."</i>";
                        echo '<br>';
                        
                    }                   
                    echo '<br>';
                    echo '<input type="submit" name="pos" value="Submit Vote">';

                        



                }
                else{
                    echo '<p style="color:red">*Sorry right now there is no candidate for this position</p>';
                }
        
     
    }

    if(isset($_POST['pos'])){
                        
        if(isset($_POST['options'])){
            
            $selected = $_SESSION['position'];
            $select = $_POST['options'];
            $name = $_SESSION['username'];
            $user_id = $_SESSION['user_id'];
            $sql="SELECT * FROM `vote` WHERE `user_id` = '$user_id' AND `voted_position` = '$selected'";
            $result = mysqli_query($con, $sql);

            if(mysqli_num_rows($result) <1){

                    $sql = "INSERT INTO vote (user_id, voted_position) VALUES('$user_id', '$selected')";
                    mysqli_query($con, $sql);

                    

                    $sql="SELECT candidate_id FROM `candidate` WHERE `candidate_name` = '$select'";
                    $result = mysqli_query($con, $sql);
        
                    if(mysqli_num_rows($result) > 0){
                        
                        $row = mysqli_fetch_row($result);
                        $candidate_id = $row[0];
                    }
                    
                    $sql="SELECT `position_id` FROM `position` WHERE `name` = '$selected'";
                    $result = mysqli_query($con, $sql);
                    if(mysqli_num_rows($result) > 0){
                        
                        $row = mysqli_fetch_row($result);
                        $position_id = $row[0];
                    }

                    $sql="SELECT * FROM `vote_per_position` WHERE `position_id` = '$position_id'";
                    $result = mysqli_query($con, $sql);
                    if (mysqli_num_rows($result) === 0){
        
                        $sql = "INSERT INTO vote_per_position (position_id) VALUES('$position_id')";
                        mysqli_query($con, $sql);
                    }

                    $sql="SELECT vote FROM `vote_per_position` WHERE `position_id` = '$position_id' ";
                    $res=mysqli_query($con, $sql); 
                    $row = mysqli_fetch_row($res);
                    $vote = $row[0];
                    $vote = $vote + 1;
                    $add = "UPDATE `vote_per_position` SET `vote` = '$vote' WHERE `position_id` = '$position_id'";
                    $insert = mysqli_query($con,$add);

        
                    $sql="SELECT * FROM `vote_per_candidate` WHERE `position_id` = '$position_id'";
                    $result = mysqli_query($con, $sql);          
                    if (mysqli_num_rows($result) === 0){
        
                        $sql = "INSERT INTO vote_per_candidate (position_id, candidate_id) VALUES('$position_id', '$candidate_id')";
                        mysqli_query($con, $sql);
                    }
                        else{
        
                            $sql="SELECT * FROM `vote_per_candidate` WHERE `position_id` = '$position_id' AND `candidate_id` = '$candidate_id'";
                            $res=mysqli_query($con, $sql);     
                            if(mysqli_num_rows($res)<1){
                                $sql = "INSERT INTO vote_per_candidate (position_id, candidate_id) VALUES('$position_id', '$candidate_id')";
                                mysqli_query($con, $sql);
                            }          
                      
                    }

                    $sql="SELECT noOfVote FROM `vote_per_candidate` WHERE `position_id` = '$position_id' AND `candidate_id` = '$candidate_id'";
                            $res=mysqli_query($con, $sql); 
                            $row = mysqli_fetch_row($res);
                            $noOfVote = $row[0];
                            $noOfVote = $noOfVote + 1;
                            $add_total = "UPDATE `vote_per_candidate` SET `noOfVote` = '$noOfVote' WHERE `candidate_id` = '$candidate_id' AND `position_id` = '$position_id'";
                            $insert_total=mysqli_query($con,$add_total);
                        $name = $_SESSION["username"];
                    if($insert_total && $insert){
                        echo '<p style="color:green;">Congratulations '.$name.', Your vote has been added to : ' . $select.'</p>';
                        echo "<br>";
                    //     echo "<h2><a href='vote3.php?results'>View Results</a></h2>";
                    //     $vote_cut="UPDATE `user` SET `vote`=vote-1 where `Name`='$session'";
                    //     $votecut=mysqli_query($con,$vote_cut);
                    
        
                    }
                }
                else{
                    echo '<p style = "color:red">*Sorry you have already voted</p>';
                }

                }
            }
        
    
    ?>


        
        
    </div>
    </form>
    </body>
<footer>
<footer>
    <center>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <p>Author:Debashish Dey</p>
  <p><a href="mailto:hege@example.com">Deydebashish71@gmail.com</a></p>
  </center>
</footer>
</html>
<?php


?>
